# SLF4SA
Syntactic and Lexical Features for Sentiment Analysis.
