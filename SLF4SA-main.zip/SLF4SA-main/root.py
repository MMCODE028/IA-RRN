import os
ROOT = os.path.dirname(os.path.abspath(__file__))
DIR_DATA = "{0}{1}data".format(ROOT, os.sep)
DIR_INPUT = "{0}{1}input{1}".format(DIR_DATA, os.sep)
DIR_RESULTS = "{0}{1}results{1}".format(DIR_DATA, os.sep)
DIR_MODELS = "{0}{1}models{1}".format(DIR_DATA, os.sep)
